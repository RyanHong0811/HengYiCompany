<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>華都集團 WALDORF GROUP</title>

    <link rel="stylesheet" href="/public/css/kule-lazy.min.css">
    <link rel="stylesheet" href="/public/css/kule-theme-default.min.css">
    <link rel="stylesheet" href="/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="public/css/waldorf.css">
</head>
<body class="index_page">
    <div class="container">
        <div class="header-bar">
            <div class="bar"></div>
            <div class="link"><a href="investor.php">投資人登入&nbsp;<i class="fa fa-fw fa-user"></i>&nbsp;</a></div>
        </div>

        <div class="header-container">
            <header>
                <a href="index.php"><h1><span>華都集團 WALDORF GROUP</span></h1></a>

                <nav>
                    <li >
                        <a href="about.php">
                            <span class="english">About Us</span>
                            <span class="chinese">關於華都</span>
                        </a>

                        <div class="columns-12 dropmenu about_us_dropmenu">
                            <div class="col-6">
                                 <ul>
                                    <li><a href="about.php#history">公司沿革</a></li>
                                    <li><a href="about.php#future">公司展望</a></li>
                                    <li><a href="about.php#team">公司團隊</a></li>
                                </ul>
                            </div>
                            <div class="col-6">
                                <img src="/public/img/main_navi_about_us.jpg" alt="">
                            </div>
                        </div>
                    </li>

                    <li >
                        <a href="companies.php">
                            <span class="english">Group Companies</span>
                            <span class="chinese">集團介紹</span>
                        </a>

                        <div class="columns-12 dropmenu group_companies_dropmenu">
                            <div class="col-4">
                                <ul>
                                    <li><a href="companies.php#financial">金融業務</a></li>
                                    <li><a href="companies.php#estate">地產業務</a></li>
                                    <li><a href="companies.php#gamble">博彩業務</a></li>
                                </ul>
                            </div>

                            <div class="col-4">
                                <ul>
                                    <li><a href="companies.php#entertainment">影視娛樂</a></li>
                                    <li><a href="companies.php#fisheries">漁農業務</a></li>
                                </ul>
                            </div>
                            <div class="col-4">
                                <img src="/public/img/main_navi_group_companies.jpg" alt="">
                            </div>
                        </div>
                    </li>

                    <li >
                        <a href="investor.php">
                            <span class="english">Investor Center</span>
                            <span class="chinese">投資人專區</span>
                        </a>
                    </li>

                    <li >
                        <a href="contact.php">
                            <span class="english">Contact Us</span>
                            <span class="chinese">聯絡我們</span>
                        </a>
                    </li>
                </nav>
            </header>
        </div>

        
        <div class="content content-index_page">
        <img src="/public/img/index_welcome_pic.jpg">

<div class="bottom_intro">
    <div class="columns-12">
        <div class="col-4">
            <img src="public/img/index_bottom_intro1.png" alt="">
            <h3>華都集團致力於提供客戶最優質的生活方式和高端的服務體驗</h3>
            <p>舉凡金融、博彩、地產、影視娛樂等。客戶的讚賞就是集團前進的動力，並持續以創新思維提供更多更好產品給客戶</p>
        </div>
        <div class="col-4">
            <img src="public/img/index_bottom_intro2.png" alt="">

            <h3>誠信為企業的最高準則，不論是面對客戶或合作夥伴</h3>
            <p>秉持著最高持信原則，這是華都集團在面對競爭激烈的市場，依然能屹立不搖的原因之一</p>
        </div>
        <div class="col-4">
            <img src="public/img/index_bottom_intro3.png" alt="">
            <h3>超越標準的管理理念一直是華都集團自成立以來對於本身的要求</h3>

            <p>唯有良好的管理才能對支持華都的客戶有所承諾。不管過去、現在、還是未來，華都集團對管理的要求只有超越標準</p>
        </div>
    </div>
</div>
        </div>
    </div>
</body>
</html>
