<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>華都集團 WALDORF GROUP</title>

    <link rel="stylesheet" href="/public/css/kule-lazy.min.css">
    <link rel="stylesheet" href="/public/css/kule-theme-default.min.css">
    <link rel="stylesheet" href="/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="public/css/waldorf.css">
</head>
<body >
    <div class="container">
        <div class="header-bar">
            <div class="bar"></div>
            <div class="link"><a href="investor.php">投資人登入&nbsp;<i class="fa fa-fw fa-user"></i>&nbsp;</a></div>
        </div>

        <div class="header-container">
            <header>
                <a href="index.php"><h1><span>華都集團 WALDORF GROUP</span></h1></a>

                <nav>
                    <li >
                        <a href="about.php">
                            <span class="english">About Us</span>
                            <span class="chinese">關於華都</span>
                        </a>

                        <div class="columns-12 dropmenu about_us_dropmenu">
                            <div class="col-6">
                                 <ul>
                                    <li><a href="about.php#history">公司沿革</a></li>
                                    <li><a href="about.php#future">公司展望</a></li>
                                    <li><a href="about.php#team">公司團隊</a></li>
                                </ul>
                            </div>
                            <div class="col-6">
                                <img src="/public/img/main_navi_about_us.jpg" alt="">
                            </div>
                        </div>
                    </li>

                    <li >
                        <a href="companies.php">
                            <span class="english">Group Companies</span>
                            <span class="chinese">集團介紹</span>
                        </a>

                        <div class="columns-12 dropmenu group_companies_dropmenu">
                            <div class="col-4">
                                <ul>
                                    <li><a href="companies.php#financial">金融業務</a></li>
                                    <li><a href="companies.php#estate">地產業務</a></li>
                                    <li><a href="companies.php#gamble">博彩業務</a></li>
                                </ul>
                            </div>

                            <div class="col-4">
                                <ul>
                                    <li><a href="companies.php#entertainment">影視娛樂</a></li>
                                    <li><a href="companies.php#fisheries">漁農業務</a></li>
                                </ul>
                            </div>
                            <div class="col-4">
                                <img src="/public/img/main_navi_group_companies.jpg" alt="">
                            </div>
                        </div>
                    </li>

                    <li >
                        <a href="investor.php">
                            <span class="english">Investor Center</span>
                            <span class="chinese">投資人專區</span>
                        </a>
                    </li>

                    <li class="active">
                        <a href="contact.php">
                            <span class="english">Contact Us</span>
                            <span class="chinese">聯絡我們</span>
                        </a>
                    </li>
                </nav>
            </header>
        </div>

                <div class="content_navigation category-contact"></div>
        
        <div class="content content-contact">
            <div id="content" class="page-contact columns-12">
        <div class="col-6 map_container">
            <img src="public/img/content_contact_map.jpg" class="map">
        </div>

        <div class="col-6 address_container">
            <img src="public/img/logo.png" class="logo" width="200">

            <address>電話：+852 3102 3133 (香港)<br>傳真：+852 3102 3202 (香港)<br>電郵：service@waldorf-group.com<br>地址：香港上環文咸東街50號寶恆商業中心22樓全層</address>
        </div>
    </div>
        </div>
    </div>
</body>
</html>
