<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>華都集團 WALDORF GROUP</title>

    <link rel="stylesheet" href="/public/css/kule-lazy.min.css">
    <link rel="stylesheet" href="/public/css/kule-theme-default.min.css">
    <link rel="stylesheet" href="/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="public/css/waldorf.css">
</head>
<body >
    <div class="container">
        <div class="header-bar">
            <div class="bar"></div>
            <div class="link"><a href="investor.php">投資人登入&nbsp;<i class="fa fa-fw fa-user"></i>&nbsp;</a></div>
        </div>

        <div class="header-container">
            <header>
                <a href="index.php"><h1><span>華都集團 WALDORF GROUP</span></h1></a>

                <nav>
                    <li >
                        <a href="about.php">
                            <span class="english">About Us</span>
                            <span class="chinese">關於華都</span>
                        </a>

                        <div class="columns-12 dropmenu about_us_dropmenu">
                            <div class="col-6">
                                 <ul>
                                    <li><a href="about.php#history">公司沿革</a></li>
                                    <li><a href="about.php#future">公司展望</a></li>
                                    <li><a href="about.php#team">公司團隊</a></li>
                                </ul>
                            </div>
                            <div class="col-6">
                                <img src="/public/img/main_navi_about_us.jpg" alt="">
                            </div>
                        </div>
                    </li>

                    <li >
                        <a href="companies.php">
                            <span class="english">Group Companies</span>
                            <span class="chinese">集團介紹</span>
                        </a>

                        <div class="columns-12 dropmenu group_companies_dropmenu">
                            <div class="col-4">
                                <ul>
                                    <li><a href="companies.php#financial">金融業務</a></li>
                                    <li><a href="companies.php#estate">地產業務</a></li>
                                    <li><a href="companies.php#gamble">博彩業務</a></li>
                                </ul>
                            </div>

                            <div class="col-4">
                                <ul>
                                    <li><a href="companies.php#entertainment">影視娛樂</a></li>
                                    <li><a href="companies.php#fisheries">漁農業務</a></li>
                                </ul>
                            </div>
                            <div class="col-4">
                                <img src="/public/img/main_navi_group_companies.jpg" alt="">
                            </div>
                        </div>
                    </li>

                    <li class="active">
                        <a href="investor.php">
                            <span class="english">Investor Center</span>
                            <span class="chinese">投資人專區</span>
                        </a>
                    </li>

                    <li >
                        <a href="contact.php">
                            <span class="english">Contact Us</span>
                            <span class="chinese">聯絡我們</span>
                        </a>
                    </li>
                </nav>
            </header>
        </div>

                <div class="content_navigation category-investor"></div>
        
        <div class="content content-login">
        
<div class="columns-12 content-login" id="content">
    <div class="col-3 section-menu">
        <h2 class="section-title"><img src="/public/img/content_small_waldorf.png">&nbsp;INVESTOR CENTER</h2>

        <p class="tips">為確保閣下資金的安全，若閣下於公眾場所使用本系統，請務必在使用完畢後登出</p>
        <p class="tips">本頁採用 HTTPS 加密協定進行資料傳輪加密，閣下可放心登入進行操作</p>
    </div>

    <div class="col-9">
        <h2 class="page-title">客戶登入 <small>Investor Login</small></h2>
            <form action="https://uc.waldorf-group.com/login" method="POST">
                <input type="hidden" name="referrer" value="1">

                <label for="username"><i class="fa fa-child"></i>&nbsp;帳號</label>
                <input type="text" name="username" class="ctrl-input">

                <label for="password"><i class="fa fa-fw fa-asterisk"></i>&nbsp;密碼</label>
                <input type="password" name="password" class="ctrl-input">

                <button type="submit" class="btn color-waldorf">登入 <small>LOG IN</small></button>
            </form>
    </div>

</div>
        </div>
    </div>
</body>
</html>
